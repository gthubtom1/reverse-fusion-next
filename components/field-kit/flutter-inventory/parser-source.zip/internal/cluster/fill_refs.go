package cluster

import (
	"fmt"

	"aotopsy/internal/dartfmt"
	"aotopsy/internal/snapshot"
)

// readFillRefs reads fill data for a FillRefs cluster, extracting name/owner/signature refs.
// When spec.IsFuncType is true, also extracts packed_parameter_counts from scalars.
// When spec.IsField is true, also extracts kind_bits and host_offset from scalars.
// For ICData, Script, LoadingUnit, KernelProgramInfo: captures all refs and
// scalars into CID-specific structured types.
func readFillRefs(s *dartfmt.Stream, cm *ClusterMeta, spec *FillSpec, fillRefUnsigned bool, profile *snapshot.VersionProfile) ([]NamedObject, []FuncTypeInfo, []FieldInfo, []TypeInfo, []ICDataInfo, []ScriptInfo, []LoadingUnitInfo, []KernelProgramInfoRef, []ClosureDataInfo, []TypeParametersInfo, []ClosureInfo, []FfiTrampolineInfo, error) {
	count := int(cm.Count)
	if count <= 0 {
		return nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil
	}

	// Capture into `named` (and thus RefToNamed) whenever there's either a
	// resolvable name OR an owner link worth walking (e.g. PatchClass has
	// no name of its own but its OwnerIdx points to the real wrapped Class).
	hasName := spec.NameIdx >= 0 || spec.OwnerIdx >= 0
	var named []NamedObject
	if hasName {
		named = make([]NamedObject, 0, count)
	}

	var funcTypes []FuncTypeInfo
	if spec.IsFuncType {
		funcTypes = make([]FuncTypeInfo, 0, count)
	}

	var fields []FieldInfo
	if spec.IsField {
		fields = make([]FieldInfo, 0, count)
	}

	var types []TypeInfo
	if spec.IsType {
		types = make([]TypeInfo, 0, count)
	}

	// CID-specific capture slices.
	var icDataInfos []ICDataInfo
	var scriptInfos []ScriptInfo
	var loadingUnitInfos []LoadingUnitInfo
	var kpiRefs []KernelProgramInfoRef
	var closureDataInfos []ClosureDataInfo
	var typeParamInfos []TypeParametersInfo
	var ffiTrampolineInfos []FfiTrampolineInfo
	// Second line of defence for the nil-profile crash fixed in
	// fillOneCluster: a nil profile (or nil CID table) now disables
	// CID-specific capture instead of panicking. The scalar/ref *stream
	// reads* below are driven by spec, not by profile, so skipping capture
	// keeps the stream aligned.
	var isICData, isScript, isLoadingUnit, isKPI, isClosureData, isTypeParameters, isClosure, isFfiTrampoline bool
	// isOldType marks the Dart 2.10-2.15 Type layout, where type_class_id is
	// a REF (a Smi) inside ReadFromTo rather than a scalar. Capturing it
	// needs allRefs, so it has to be in the set below -- it was not, so the
	// capture block further down ("v2.x TypeClassIdIsRef") always saw an
	// empty allRefs and never ran: clResult.Types came out EMPTY for every
	// 2.x snapshot (2187 Type objects in the 2.12 sample, 0 captured).
	//
	// Everything typed hangs off that: FieldTypes (declared field types),
	// BuildClassHierarchy (superclasses, hence LCA and CHA), and the pool's
	// Type -> class resolution. With it empty, 2.x had no field types at all
	// and dispatch resolution had almost nothing to work from.
	var isOldType bool
	if profile != nil && profile.CIDs != nil {
		isICData = cm.CID == profile.CIDs.ICData
		isScript = cm.CID == profile.CIDs.Script
		isLoadingUnit = cm.CID == profile.CIDs.LoadingUnit
		isKPI = cm.CID == profile.CIDs.KernelProgramInfo
		isClosureData = cm.CID == profile.CIDs.ClosureData
		isTypeParameters = profile.CIDs.TypeParameters != 0 && cm.CID == profile.CIDs.TypeParameters
		isClosure = cm.CID == profile.CIDs.Closure
		isOldType = profile.TypeClassIdIsRef && cm.CID == profile.CIDs.Type
		isFfiTrampoline = profile.CIDs.FfiTrampolineData != 0 && cm.CID == profile.CIDs.FfiTrampolineData
	}

	var closures []ClosureInfo
	if isClosure {
		closures = make([]ClosureInfo, 0, count)
	}

	ref := cm.StartRef
	for i := 0; i < count; i++ {
		// v2.10: Read<bool>(is_canonical) — 1 raw byte before refs.
		if spec.LeadingBool {
			if _, err := s.ReadByte(); err != nil {
				return named, funcTypes, fields, types, icDataInfos, scriptInfos, loadingUnitInfos, kpiRefs, closureDataInfos, typeParamInfos, closures, ffiTrampolineInfos, fmt.Errorf("obj %d/%d is_canonical: %w", i, count, err)
			}
		}

		var nameRef, ownerRef, sigRef, paramTypesRef, fieldTypeRef, typeParamsRef, resultTypeRef, namedParamNamesRef int
		nameRef = -1
		ownerRef = -1
		sigRef = -1
		paramTypesRef = -1
		fieldTypeRef = -1
		typeParamsRef = -1
		resultTypeRef = -1
		namedParamNamesRef = -1
		dataRef := -1

		// For CID-specific capture, save all refs in order.
		var allRefs []int

		// Read refs using version-appropriate encoding.
		// Variable-length ref objects (Dart 3.13.0 Closure): the fill reads
		// the element count first, then the fixed refs plus that many more.
		numRefs := spec.NumRefs
		if spec.VarLenRefs {
			n, err := s.ReadUnsigned()
			if err != nil {
				return named, funcTypes, fields, types, icDataInfos, scriptInfos, loadingUnitInfos, kpiRefs, closureDataInfos, typeParamInfos, closures, ffiTrampolineInfos, fmt.Errorf("obj %d/%d varlen length: %w", i, count, err)
			}
			if n < 0 || int(n) > 1<<20 {
				return named, funcTypes, fields, types, icDataInfos, scriptInfos, loadingUnitInfos, kpiRefs, closureDataInfos, typeParamInfos, closures, ffiTrampolineInfos, fmt.Errorf("obj %d/%d varlen length %d out of range", i, count, n)
			}
			numRefs += int(n)
		}

		for j := 0; j < numRefs; j++ {
			r, err := readRef(s, fillRefUnsigned)
			if err != nil {
				return named, funcTypes, fields, types, icDataInfos, scriptInfos, loadingUnitInfos, kpiRefs, closureDataInfos, typeParamInfos, closures, ffiTrampolineInfos, fmt.Errorf("obj %d/%d ref %d: %w", i, count, j, err)
			}
			if isICData || isScript || isLoadingUnit || isKPI || isClosureData || isTypeParameters || isOldType || isClosure || isFfiTrampoline || spec.IsType {
				allRefs = append(allRefs, int(r))
			}
			if j == spec.NameIdx {
				nameRef = int(r)
			}
			if j == spec.OwnerIdx {
				ownerRef = int(r)
			}
			if spec.SignatureIdx > 0 && j == spec.SignatureIdx {
				sigRef = int(r)
			}
			if spec.IsFuncType && spec.FuncTypeParamTypesIdx > 0 && j == spec.FuncTypeParamTypesIdx {
				paramTypesRef = int(r)
			}
			// type_parameters sits two slots before parameter_types; see
			// FuncTypeInfo.TypeParamsRefID for the raw_object.h evidence.
			if spec.IsFuncType && spec.FuncTypeParamTypesIdx >= 2 && j == spec.FuncTypeParamTypesIdx-2 {
				typeParamsRef = int(r)
			}
			// result_type sits one slot before parameter_types; see
			// FuncTypeInfo.ResultTypeRefID for the raw_object.h evidence.
			if spec.IsFuncType && spec.FuncTypeParamTypesIdx >= 1 && j == spec.FuncTypeParamTypesIdx-1 {
				resultTypeRef = int(r)
			}
			// named_parameter_names sits one slot AFTER parameter_types;
			// see FuncTypeInfo.NamedParamNamesArrayRefID for the raw_object.h
			// evidence. UntaggedFunctionType lays out type_parameters,
			// result_type, parameter_types, named_parameter_names
			// consecutively (VISIT_TO(named_parameter_names)).
			if spec.IsFuncType && spec.FuncTypeParamTypesIdx > 0 && j == spec.FuncTypeParamTypesIdx+1 {
				namedParamNamesRef = int(r)
			}
			// Field type ref is at index 2 (refs: name=0, owner=1, type=2, initializer=3).
			if spec.IsField && j == 2 {
				fieldTypeRef = int(r)
			}
			// Function.data; for closures it is the ClosureData. Its index
			// moved with signature at 2.14.0 -- see specFunction.
			if spec.IsFunction && spec.DataIdx > 0 && j == spec.DataIdx {
				dataRef = int(r)
			}
			// Before FunctionType existed the signature lived on the Function
			// itself; see FunctionRefLayout.
			if spec.IsFunction && spec.ResultTypeIdx > 0 && j == spec.ResultTypeIdx {
				resultTypeRef = int(r)
			}
			if spec.IsFunction && spec.ParamTypesIdx > 0 && j == spec.ParamTypesIdx {
				paramTypesRef = int(r)
			}
		}

		// Read scalars; extract type-specific data for FunctionType and Field clusters.
		var ss scalarState
		for si, op := range spec.Scalars {
			switch {
			case spec.IsFunction:
				if err := readFunctionScalar(s, si, len(spec.Scalars), &ss, i, count, profile, op, funcPackedFieldsFor(profile.DartVersion)); err != nil {
					return named, funcTypes, fields, types, icDataInfos, scriptInfos, loadingUnitInfos, kpiRefs, closureDataInfos, typeParamInfos, closures, ffiTrampolineInfos, err
				}
			case spec.IsFuncType:
				fti, err := readFuncTypeScalar(s, si, ref, paramTypesRef, typeParamsRef, resultTypeRef, namedParamNamesRef, i, count, op, spec.PackedParams)
				if err != nil {
					return named, funcTypes, fields, types, icDataInfos, scriptInfos, loadingUnitInfos, kpiRefs, closureDataInfos, typeParamInfos, closures, ffiTrampolineInfos, err
				}
				if fti != nil {
					funcTypes = append(funcTypes, *fti)
				}
			case spec.IsField:
				fi, err := readFieldScalar(s, si, ref, nameRef, ownerRef, sigRef, fieldTypeRef, &ss, i, count, op)
				if err != nil {
					return named, funcTypes, fields, types, icDataInfos, scriptInfos, loadingUnitInfos, kpiRefs, closureDataInfos, typeParamInfos, closures, ffiTrampolineInfos, err
				}
				if fi != nil {
					fields = append(fields, *fi)
				}
			case spec.IsType:
				ti, err := readTypeScalar(s, si, ref, i, count, op, spec.TypeClassIDIsScalar0, spec.TypeClassIDShift)
				if err != nil {
					return named, funcTypes, fields, types, icDataInfos, scriptInfos, loadingUnitInfos, kpiRefs, closureDataInfos, typeParamInfos, closures, ffiTrampolineInfos, err
				}
				if ti != nil {
					ti.ArgumentsRef = typeArgumentsRef(allRefs, profile.DartVersion)
					types = append(types, *ti)
				}
			case isScript:
				if err := readScriptScalar(s, si, profile, &ss, i, count); err != nil {
					return named, funcTypes, fields, types, icDataInfos, scriptInfos, loadingUnitInfos, kpiRefs, closureDataInfos, typeParamInfos, closures, ffiTrampolineInfos, err
				}
			case isLoadingUnit:
				if err := readLoadingUnitScalar(s, &ss, i, count); err != nil {
					return named, funcTypes, fields, types, icDataInfos, scriptInfos, loadingUnitInfos, kpiRefs, closureDataInfos, typeParamInfos, closures, ffiTrampolineInfos, err
				}
			case isFfiTrampoline:
				if err := readFfiTrampolineScalar(s, si, &ss, op); err != nil {
					return named, funcTypes, fields, types, icDataInfos, scriptInfos, loadingUnitInfos, kpiRefs, closureDataInfos, typeParamInfos, closures, ffiTrampolineInfos, err
				}
			default:
				if err := skipScalar(s, op); err != nil {
					return named, funcTypes, fields, types, icDataInfos, scriptInfos, loadingUnitInfos, kpiRefs, closureDataInfos, typeParamInfos, closures, ffiTrampolineInfos, fmt.Errorf("obj %d/%d scalar: %w", i, count, err)
				}
			}
		}

		// CID-specific capture: build structured types from allRefs + scalars.
		if isICData && len(allRefs) >= 3 {
			// ICData ReadFromTo order (ICDataDeserializationCluster::ReadFill,
			// UntaggedICData): target_name(0), args_descriptor(1), entries(2).
			//
			// UNVERIFIED AGAINST A REAL BINARY, and expected to stay that way:
			// no AOT snapshot in the corpus contains an ICData cluster (0 in
			// all 16 samples across Dart 2.12/3.7/3.9/3.10/3.11/3.12). ICData
			// is a JIT inline cache; the AOT precompiler drops ic_data_array_.
			// So this branch is a capture-if-it-ever-appears path only. Do NOT
			// build analysis features on it -- an earlier revision did (BLR
			// resolution keyed on ICData) and it resolved exactly zero call
			// sites while reporting the *owner's* name as the call target.
			icDataInfos = append(icDataInfos, ICDataInfo{
				RefID:         ref,
				TargetNameRef: allRefs[0],
				ArgsDescRef:   allRefs[1],
				EntriesRef:    allRefs[2],
			})
		}
		if isClosure {
			// UntaggedClosure ReadFromTo:
			// Pre-3.13.0: instantiator_type_arguments(0), function_type_arguments(1),
			//             delayed_type_arguments(2), function(3), context(4), hash(5).
			// Dart 3.13.0+: length_and_flags(0), hash(1), function(2), variable captured refs...
			fnIdx := 3
			minRefs := 4
			if profile != nil && snapshot.VersionAtLeast(profile.DartVersion, "3.13.0") {
				fnIdx = 2
				minRefs = 3
			}
			if len(allRefs) >= minRefs {
				closures = append(closures, ClosureInfo{
					RefID:       ref,
					FunctionRef: int(allRefs[fnIdx]),
				})
			}
		}
		if isScript && len(allRefs) >= 1 {
			si := ScriptInfo{
				RefID:             ref,
				URLRef:            allRefs[0],
				LineOffset:        ss.scriptLine,
				ColOffset:         ss.scriptCol,
				KernelScriptIndex: ss.scriptKernelIdx,
			}
			_ = ss.scriptFlags // captured but not stored in struct (rarely needed)
			scriptInfos = append(scriptInfos, si)
		}
		if isLoadingUnit && len(allRefs) >= 1 {
			// LoadingUnit refs: parent(0). Scalar: id.
			lui := LoadingUnitInfo{
				RefID:     ref,
				ParentRef: allRefs[0],
				UnitID:    ss.loadingUnitID,
			}
			loadingUnitInfos = append(loadingUnitInfos, lui)
		}
		if isKPI && len(allRefs) >= 9 {
			// KPI refs: kernel_component(0), string_offsets(1), string_data(2),
			// canonical_names(3), metadata_payloads(4), metadata_mappings(5),
			// scripts(6), constants(7), constants_table(8).
			kpiRefs = append(kpiRefs, KernelProgramInfoRef{
				RefID:              ref,
				KernelComponentRef: allRefs[0],
				StringOffsetsRef:   allRefs[1],
				StringDataRef:      allRefs[2],
				CanonicalNamesRef:  allRefs[3],
				ConstantsRef:       allRefs[7],
				ConstantsTableRef:  allRefs[8],
			})
		}
		if isClosureData && len(allRefs) >= 2 {
			// ClosureData refs in AOT: parent_function(0), closure(1).
			// context_scope_ is null in AOT (not read from stream).
			cd := ClosureDataInfo{
				RefID:             ref,
				ParentFunctionRef: allRefs[0],
				ClosureRef:        allRefs[1],
			}
			closureDataInfos = append(closureDataInfos, cd)
		}
		if isFfiTrampoline && len(allRefs) >= 4 {
			ffiTrampolineInfos = append(ffiTrampolineInfos, FfiTrampolineInfo{
				RefID:                        ref,
				SignatureTypeRef:             allRefs[0],
				CSignatureRef:                allRefs[1],
				CallbackTargetRef:            allRefs[2],
				CallbackExceptionalReturnRef: allRefs[3],
				CallbackID:                   ss.callbackID,
				FfiFunctionKind:              ss.ffiKind,
			})
		}
		// v2.x TypeClassIdIsRef: Type.type_class_id is a Smi ref.
		// Capture it so BuildTypeContext can resolve it via MintValues.
		// Ref index depends on version:
		//   v2.10 (NumRefs=5): type_test_stub(0), type_class_id(1), arguments(2), hash(3), signature(4)
		//   v2.12-v2.13 (NumRefs=4): type_test_stub(0), type_class_id(1), arguments(2), hash(3)
		//   v2.14 (NumRefs=3): type_class_id(0), arguments(1), hash(2)
		if profile.TypeClassIdIsRef && profile.CIDs != nil && cm.CID == profile.CIDs.Type && len(allRefs) > 0 {
			typeClassIdIdx := 1 // default for v2.10-v2.13 (NumRefs >= 4)
			if spec.NumRefs == 3 {
				typeClassIdIdx = 0 // v2.14: type_class_id at index 0
			}
			if typeClassIdIdx < len(allRefs) {
				types = append(types, TypeInfo{
					RefID:          ref,
					ClassID:        0, // resolved later via MintValues
					TypeClassIdRef: allRefs[typeClassIdIdx],
					ArgumentsRef:   typeArgumentsRef(allRefs, profile.DartVersion),
				})
			}
		}
		if isTypeParameters && len(allRefs) >= 4 {
			// UntaggedTypeParameters ReadFromTo: names(0), flags(1),
			// bounds(2), defaults(3).
			typeParamInfos = append(typeParamInfos, TypeParametersInfo{
				RefID:         ref,
				NamesArrayRef: allRefs[0],
				FlagsRef:      allRefs[1],
				BoundsRef:     allRefs[2],
				DefaultsRef:   allRefs[3],
			})
		}

		if hasName {
			named = append(named, NamedObject{
				CID:               cm.CID,
				RefID:             ref,
				NameRefID:         nameRef,
				OwnerRefID:        ownerRef,
				SignatureRefID:    sigRef,
				DataRefID:         dataRef,
				ResultTypeRefID:   funcRefOr(spec.IsFunction, spec.ResultTypeIdx, resultTypeRef),
				ParamTypesRefID:   funcRefOr(spec.IsFunction, spec.ParamTypesIdx, paramTypesRef),
				CodeIndex:         ss.codeIndex,
				NumFixedParams:    ss.numFixed,
				NumOptionalParams: ss.numOptional,
				IsStatic:          ss.isStatic,
				IsSuspendable:     ss.isSuspendable,
				HasKindTag:        ss.hasKindTag,
				FuncKind:          ss.funcKind,
			})
		}
		ref++
	}

	return named, funcTypes, fields, types, icDataInfos, scriptInfos, loadingUnitInfos, kpiRefs, closureDataInfos, typeParamInfos, closures, ffiTrampolineInfos, nil
}

// funcRefOr returns ref when this spec actually captured that Function field,
// and -1 otherwise. resultTypeRef/paramTypesRef are shared with the FunctionType
// path, so without this guard a FunctionType's values would leak onto a
// NamedObject that never read them.
func funcRefOr(isFunction bool, idx, ref int) int {
	if isFunction && idx > 0 {
		return ref
	}
	return -1
}

// skipScalar reads and discards one scalar value.
func skipScalar(s *dartfmt.Stream, op ScalarOp) error {
	switch op {
	case OpTagged32, OpUint16, OpInt16:
		// Read<int32_t/uint32_t/uint16_t/int16_t>: variable-length, marker 192.
		_, err := s.ReadTagged32()
		return err
	case OpTagged64:
		// Read<int64_t/double/uword>: variable-length, marker 192.
		_, err := s.ReadTagged64()
		return err
	case OpUnsigned:
		// ReadUnsigned: variable-length, marker 128.
		_, err := s.ReadUnsigned()
		return err
	case OpBool, OpUint8, OpInt8:
		// Read<uint8_t/int8_t/bool>: Raw<1,T> = 1 raw byte.
		_, err := s.ReadByte()
		return err
	case OpRefId:
		// ReadRef: big-endian signed-byte accumulation (trailing ref after scalars).
		_, err := s.ReadRefId()
		return err
	default:
		return fmt.Errorf("unknown scalar op %d", op)
	}
}

// typeRefsAfterArguments is how many refs follow UntaggedType.arguments inside
// the visited range, which is what decides where `arguments` sits counting
// back from the end. raw_object.h, at every supported version:
//
//	2.10.0     ... arguments, hash, signature   VISIT_TO(signature_)   2
//	2.12-2.13  ... arguments, hash              VISIT_TO(hash)         1
//	2.14-3.0.5 ... arguments, hash              VISIT_TO(hash)         1
//	3.1.0+     ... arguments                    VISIT_TO(arguments)    0
//
// Counting back rather than forward keeps this independent of what precedes
// `arguments`, which moved twice on its own (type_test_stub left the range at
// 2.14 and came back at 2.15; type_class_id stopped being a ref at 2.15).
func typeRefsAfterArguments(dartVersion string) int {
	switch {
	case snapshot.VersionAtLeast(dartVersion, "3.1.0"):
		return 0
	case snapshot.VersionAtLeast(dartVersion, "2.12.0"):
		return 1
	default:
		return 2 // 2.10.0 also carries `signature`
	}
}

// typeArgumentsRef picks UntaggedType.arguments out of the Type cluster's
// visited ref list.
//
// This used to be an unconditional "last ref", which is right only from 3.1.0
// on. Below that it captured `hash` -- a Smi -- so the TypeArguments lookup
// missed every time and no type-testing stub ever got its type arguments.
// Measured: 0 of 2146 Types on dart-2.16.0-gt-arm64 resolved to a
// TypeArguments object, 0 of 2310 on 2.19.0, against 745 of 2447 on 3.3.0.
//
// Returns -1 when there are too few refs to name one.
func typeArgumentsRef(allRefs []int, dartVersion string) int {
	idx := len(allRefs) - 1 - typeRefsAfterArguments(dartVersion)
	if idx < 0 || idx >= len(allRefs) {
		return -1
	}
	return allRefs[idx]
}
